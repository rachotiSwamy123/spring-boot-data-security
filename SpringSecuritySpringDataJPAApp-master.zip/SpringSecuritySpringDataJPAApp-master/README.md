# Spring Security 4 for Spring MVC using Spring Data JPA and Spring Boot

Video Tutorial - https://youtu.be/XO-OdIXNU_o

Step by Step Guide - http://www.programming-free.com/2016/01/spring-security-spring-data-jpa.html
